﻿# shared Qenex script data
for index in range(1001):
	if index % 100 == 0:
		print(f"index is {index}")