alpha = 0.25
cum_val += alpha * (LivingRoomTemp.Value - cum_val)
FilteredTemp.Value = cum_val

counter += 1
#print(f"filter index {counter}")