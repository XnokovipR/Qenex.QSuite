cum_val = 0
counter = 0