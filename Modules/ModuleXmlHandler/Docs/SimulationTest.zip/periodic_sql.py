temp_val = LivingRoomTemp.Value
pressure_val = LivingRoomPressure.Value

with postgres_connection.cursor() as cursor:
	insert_variable_value(cursor, temp_id, temp_val)
	insert_variable_value(cursor, pressure_id, pressure_val)
 
postgres_connection.commit()

print(f"periodic => {LivingRoomTemp.Name}/{temp_id}: {temp_val}")
print(f"periodic => {LivingRoomPressure.Name}/{pressure_id}: {pressure_val}")