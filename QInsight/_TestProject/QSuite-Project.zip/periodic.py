﻿#from qenex_scripts_shared import *

print("Period 1000 ms - python script executed")